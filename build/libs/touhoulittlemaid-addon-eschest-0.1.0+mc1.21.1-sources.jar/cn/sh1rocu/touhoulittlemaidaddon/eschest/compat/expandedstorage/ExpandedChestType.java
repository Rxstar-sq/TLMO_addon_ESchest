package cn.sh1rocu.touhoulittlemaidaddon.eschest.compat.expandedstorage;

import com.github.tartaricacid.touhoulittlemaid.api.bauble.IChestType;
import com.github.tartaricacid.touhoulittlemaid.inventory.chest.ChestManager;
import net.fabricmc.fabric.api.transfer.v1.item.ItemStorage;
import net.fabricmc.loader.api.FabricLoader;
import net.minecraft.class_1263;
import net.minecraft.class_1657;
import net.minecraft.class_1922;
import net.minecraft.class_2338;
import net.minecraft.class_2586;
import net.minecraft.class_2741;
import net.minecraft.class_2960;
import net.minecraft.class_7923;

public final class ExpandedChestType implements IChestType {
    private static final String EXPANDED_CHEST_ID = "expandedstorage";

    private static boolean isExpandedStorageContainer(class_2586 chest) {
        if (chest == null || chest.method_10997() == null) {
            return false;
        }
        class_2960 blockId = class_7923.field_41175.method_10221(chest.method_11010().method_26204());
        if (blockId == null || !EXPANDED_CHEST_ID.equals(blockId.method_12836())) {
            return false;
        }
        return ItemStorage.SIDED.find(chest.method_10997(), chest.method_11016(), chest.method_11010(), chest, null) != null;
    }

    public static void register(ChestManager manager) {
        if (FabricLoader.getInstance().isModLoaded(EXPANDED_CHEST_ID)) {
            manager.add(new ExpandedChestType());
        }
    }

    @Override
    public boolean isChest(class_2586 chest) {
        if (!FabricLoader.getInstance().isModLoaded(EXPANDED_CHEST_ID)) {
            return false;
        }
        return isExpandedStorageContainer(chest);
    }

    @Override
    public boolean canOpenByPlayer(class_2586 chest, class_1657 player) {
        if (!FabricLoader.getInstance().isModLoaded(EXPANDED_CHEST_ID) || !isExpandedStorageContainer(chest)) {
            return false;
        }
        if (chest instanceof class_1263 container) {
            return container.method_5443(player);
        }
        return false;
    }

    @Override
    public int getOpenCount(class_1922 level, class_2338 pos, class_2586 chest) {
        if (!FabricLoader.getInstance().isModLoaded(EXPANDED_CHEST_ID) || !isExpandedStorageContainer(chest)) {
            return DENY_COUNT;
        }
        if (chest.method_11010().method_28498(class_2741.field_12537)
                && chest.method_11010().method_11654(class_2741.field_12537)) {
            return 1;
        }
        return ALLOW_COUNT;
    }
}
